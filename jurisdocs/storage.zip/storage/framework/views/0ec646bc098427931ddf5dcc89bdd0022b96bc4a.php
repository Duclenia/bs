<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">

        <ul class="nav side-menu">

            <li><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-tachometer"></i> <?php echo e(__('Dashboard')); ?></a></li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_list')): ?>
                <li><a href="<?php echo e(route('clients.index')); ?>"><i class="fa fa-user-plus"></i> <?php echo e(__('Clients')); ?></a></li>
            <?php endif; ?>



            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('case_list')): ?>
                <li><a href="<?php echo e(route('processo.index')); ?>"><i class="fa fa-gavel"></i> Processos</a></li>
            <?php endif; ?>

            <?php if(auth()->user()->user_type == 'Cliente'): ?>

                <?php if(auth()->user()->cliente->processos()->count()): ?>
                    <li><a href="<?php echo e(url('cliente/processos')); ?>"><i class="fa fa-gavel"></i> Meus Processos</a></li>
                <?php endif; ?>

                    <li><a><i class="fa fa-money"></i> <?php echo e(__('Agendamentos')); ?> <span
                                class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">

                                <li><a href="<?php echo e(route('cliente.reuniao.index')); ?>"><?php echo e(__('form reuniao')); ?></a></li>

                                <li><a href="<?php echo e(route('cliente.consulta.index')); ?>"><?php echo e(__('form consulta')); ?></a>


                        </ul>
                    </li>

            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_list')): ?>
                <li><a href="<?php echo e(route('tarefas.index')); ?>"><i class="fa fa-tasks"></i><?php echo e(__('Tasks')); ?></a></li>
            <?php endif; ?>


            
            <?php if(auth()->user()->can('service_list') || auth()->user()->can('invoice_list')): ?>
                <li><a><i class="fa fa-money"></i> <?php echo e(__('Agendamentos')); ?> <span
                            class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_list')): ?>
                            <li><a href="<?php echo e(route('reuniao.index')); ?>"><?php echo e(__('form reuniao')); ?></a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_list')): ?>
                            <li><a href="<?php echo e(route('consulta.index')); ?>"><?php echo e(__('form consulta')); ?></a>
                            <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->user_type == 'SuperAdmin'): ?>
                <li><a><i class="fa fa-users"></i> <?php echo e(__('Team members')); ?> <span
                            class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                        <li><a href="<?php echo e(url('admin/client_user')); ?>"> <?php echo e(__('Team members')); ?></a></li>
                        <li><a href="<?php echo e(route('funcao.index')); ?>"><?php echo e(__('Role')); ?></a></li>

                    </ul>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_planos')): ?>
                <li>
                    <a href="<?php echo e(route('plano.index')); ?>"><i class="fa fa-user-plus"></i> <?php echo e(__('plans')); ?></a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_subscricao')): ?>
                <li>
                    <a href="<?php echo e(route('subscricao.index')); ?>">
                        <i class="fa fa-calendar-plus-o"></i>
                        <?php echo e(__('Subscriptions')); ?>

                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vendor_list')): ?>
                <li><a href="<?php echo e(route('fornecedor.index')); ?>"><i class="fa fa-user-plus"></i> Fornecedores</a></li>
            <?php endif; ?>

            <?php if(auth()->user()->can('service_list') || auth()->user()->can('invoice_list')): ?>
                <li><a><i class="fa fa-money"></i> <?php echo e(__('Income')); ?> <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service_list')): ?>
                            <li><a href="<?php echo e(url('admin/servico')); ?>"><?php echo e(__('Services')); ?></a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_list')): ?>
                            <li><a href="<?php echo e(url('admin/factura')); ?>"><?php echo e(__('Invoice')); ?></a>
                            <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('expense_type_list') || auth()->user()->can('expense_list')): ?>
                <li><a><i class="fa fa-money"></i> <?php echo e(__('Expenses')); ?> <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_type_list')): ?>
                            <li><a href="<?php echo e(url('admin/expense-type')); ?>"><?php echo e(__('Expense Type')); ?></a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expense_list')): ?>
                            <li><a href="<?php echo e(url('admin/expense')); ?>"><?php echo e(__('Expenses')); ?></a></li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>

            <?php if(auth()->user()->user_type != 'Cliente'): ?>
                <li><a><i class="fa fa-gear"></i> <?php echo e(__('Settings')); ?> <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('case_type_list')): ?>
                            <li><a href="<?php echo e(url('admin/case-type')); ?>">Tipo de Processo</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_crime_enquad')): ?>
                            <li><a href="<?php echo e(url('admin/crime-enquad')); ?>">Enquadramento do crime</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_crime_subenquad')): ?>
                            <li><a href="<?php echo e(url('admin/crime-sub-enquad')); ?>">Sub-enquadramento do crime</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_crime')): ?>
                            <li><a href="<?php echo e(url('admin/crime')); ?>">Tipo de crime</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_orgao_judiciario')): ?>
                            <li><a href="<?php echo e(url('admin/orgao-judiciario')); ?>">&Oacute;rg&atilde;o judici&aacute;rio</a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('court_list')): ?>
                            <li><a href="<?php echo e(url('admin/tribunal')); ?>"><?php echo e(__('Court')); ?></a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_seccao')): ?>
                            <li><a href="<?php echo e(url('admin/seccao')); ?>">Sec&ccedil;&atilde;o</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_bairro')): ?>
                            <li><a href="<?php echo e(url('admin/bairro')); ?>">Bairro</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('listar_intervdesignacao')): ?>
                            <li><a href="<?php echo e(url('admin/interv-designacao')); ?>">Interv. designa&ccedil;&atilde;o</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('case_status_list')): ?>
                            <li><a href="<?php echo e(url('admin/case-status')); ?>">Estado do processo</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('judge_list')): ?>
                            <li><a href="<?php echo e(url('admin/juiz')); ?>"><?php echo e(__('Judge')); ?></a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tax_list')): ?>
                            <li><a href="<?php echo e(url('admin/tax')); ?>">Imposto</a></li>
                        <?php endif; ?>


                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general_setting_edit')): ?>
                            <li><a href="<?php echo e(url('admin/general-setting')); ?>"><?php echo e(__('General Setting')); ?></a></li>
                        <?php endif; ?>

                        <?php if(auth()->user()->user_type == 'Admin'): ?>
                            <li><a href="<?php echo e(url('admin/database-backup')); ?>"><?php echo e(__('Database Backup')); ?></a></li>
                        <?php endif; ?>

                    </ul>
                </li>
            <?php endif; ?>

        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\bs\jurisdocs\resources\views/admin/layout/sidebar.blade.php ENDPATH**/ ?>