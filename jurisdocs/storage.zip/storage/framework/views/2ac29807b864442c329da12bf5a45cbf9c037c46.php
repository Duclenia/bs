
<div>
    <footer>
        <div class="clearfix">©2021 JurisDocs - Gest&atilde;o de Escrit&oacute;rio de Advogados. Desenvolvido por Mwango Click</div>
    </footer>

</div><?php /**PATH C:\xampp\htdocs\bs\jurisdocs\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>